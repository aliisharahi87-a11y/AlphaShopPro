import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
ADMIN_IDS = {
    int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",")
    if x.strip().isdigit()
}

REQUIRED_CHANNEL = os.getenv("REQUIRED_CHANNEL", "@alphashopss").strip()
SUPPORT_USERNAME = os.getenv("SUPPORT_USERNAME", "@AlphaShopSupport").strip()

CARD_NUMBER = os.getenv("CARD_NUMBER", "").strip()
CARD_HOLDER = os.getenv("CARD_HOLDER", "").strip()

CUSTOM_PRICE_PER_GB = int(os.getenv("CUSTOM_PRICE_PER_GB", "4000") or 4000)
REFERRAL_PERCENT = 5

DATABASE_FILE = os.getenv("DATABASE_FILE", "alphashop.db")

PANEL_API_URL = os.getenv("PANEL_API_URL", "").strip()
PANEL_API_TOKEN = os.getenv("PANEL_API_TOKEN", "").strip()
