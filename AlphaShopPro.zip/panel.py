import aiohttp
from config import PANEL_API_URL, PANEL_API_TOKEN


async def create_customer(username, gb, unlimited=False):
    """
    Generic API adapter.
    Configure PANEL_API_URL and PANEL_API_TOKEN in .env.
    The exact endpoint/payload must match the official API of your panel.
    """
    if not PANEL_API_URL:
        return {"ok": False, "error": "PANEL_API_URL is not configured"}

    headers = {"Accept": "application/json", "Content-Type": "application/json"}
    if PANEL_API_TOKEN:
        headers["Authorization"] = f"Bearer {PANEL_API_TOKEN}"

    payload = {
        "username": username,
        "traffic_gb": gb,
        "unlimited": unlimited,
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                PANEL_API_URL,
                headers=headers,
                json=payload,
                timeout=30,
            ) as response:
                data = await response.json(content_type=None)
                return {"ok": response.status < 400, "data": data}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
